//40223028 - ZAHRA HEYDARI
#include <stdio.h>
#include <math.h>
void solver(float a,float b,float c,float *root1,float *root2,int *countroot);
int main()
{
    float a,b,c,root1,root2;
    int countroot;

    // get numbers
    printf("Enter a:\n");
    scanf("%f",&a);
    printf("Enter b:\n");
    scanf("%f",&b);
    printf("Enter c:\n");
    scanf("%f",&c);

    // check if they are valid
    if ((a == 0) && (b == 0)){
        printf("NOT VALID input.\n");
    }else{
        // find the roots using the function 
        solver(a,b,c,&root1,&root2,&countroot);

        // printing results
        printf("The quadratic equation to solve: %f x^2 + (%f) x + (%f) = 0\n",a,b,c);
        if (countroot == 2){
            printf("TWO real roots.\nroot1= %f\nroot2= %f\n",root1,root2);
        }else if(countroot == 1){
            printf("ONE real root.\nroot= %f\n",root1);
        }else{
            printf("The equation has NO REAL ROOTS.\n");
        }

    }
    

    return 0;
}

void solver(float a,float b,float c,float *root1,float *root2,int *countroot)
{
    float delta = (b*b) - (4*a*c);
    if (delta > 0){
        *countroot = 2;
        *root1 = ((-b + sqrt(delta)) / (2*a) );
        *root2 = ((-b - sqrt(delta)) / (2*a) );
    }else if(delta == 0){
        *countroot = 1;
        *root1 = ((-b + sqrt(delta)) / (2*a) );
    }else{
        *countroot = 0;
    }
}